def add_contact(contacts, name, phone): 
  if len(phone)==10:
      if contacts!={} and name in contacts:
          return 'Contact is already present in the database'
      else:
          contacts[name]= phone
      return contacts
  else:
      return 'Invalid phone number'

def search_contact(contacts, name):
  if name in contacts:
      return contacts[name]
  else:
      return 'Not found'

def delete_contact(contacts, name):
  if name in contacts:
      del contacts[name]
      return True
  else:
      return False

def update_contact_phone(contacts, name, new_phone):
  if len(new_phone)==10:
      if name in contacts:
          contacts[name]= new_phone
          return contacts
      else:
          return 'Contact Not found'
  else:
      return 'Invalid phone number.'

def get_all_contacts(contacts):
  get_name=[]
  for key in contacts:
      get_name.append(key)
  return get_name

def count_contacts(contacts):
  count=0
  for key in contacts:
      count+=1
  return count
def get_contacts_by_prefix(contacts, prefix):
  get_name=[]
  for key in contacts:
      if key.startswith(prefix):
          get_name.append(key)
  return get_name

def get_contact_names(contacts):
  get_name =[]
  for key in contacts:
      get_name.append(key)
  return sorted(get_name)

def get_phone_by_partial_name(contacts, partial_name):
  get_num=[]
  for key in contacts:
      if key.startswith(partial_name):
          get_num.append(contacts[key])
  return set(get_num)

def merge_contact_lists(contacts1, contacts2):
  return contacts1|contacts2