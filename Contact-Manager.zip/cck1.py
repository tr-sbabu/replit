def add_contact(contacts, name, phone):
    """
    Adds a new contact with the given name and phone number.
    """
    if not phone.isdigit() or len(phone) != 10:
        return "Invalid phone number."
    
    normalized_name = name.lower()
    
    if normalized_name not in contacts:
        contacts[normalized_name] = {'name': name, 'phone': phone}
    return contacts

def search_contact(contacts, name):
    """
    Searches for a contact by name and returns the phone number or 'Not found'.
    """
    normalized_name = name.lower()
    if normalized_name in contacts:
        return contacts[normalized_name]['phone']
    return "Not found"

def delete_contact(contacts, name):
    """
    Deletes a contact by name and returns True if successful, otherwise False.
    """
    normalized_name = name.lower()
    if normalized_name in contacts:
        del contacts[normalized_name]
        return True
    return False

def update_contact_phone(contacts, name, new_phone):
    """
    Updates the phone number of an existing contact.
    """
    normalized_name = name.lower()
    if normalized_name in contacts:
        if new_phone.isdigit() and len(new_phone) == 10:
            contacts[normalized_name]['phone'] = new_phone
            return contacts
        return "Invalid phone number."
    return "Contact not found."

def get_all_contacts(contacts):
    """
    Returns a list of all contacts.
    """
    all_contacts = []
    for details in contacts.values():
        all_contacts.append(details['name'])
    return all_contacts

def count_contacts(contacts):
    """
    Returns the total number of contacts.
    """
    return len(contacts)

def get_contacts_by_prefix(contacts, prefix):
    """
    Returns a list of contacts whose names start with the given prefix.
    """
    prefix = prefix.lower()
    contacts_with_prefix = []
    for details in contacts.values():
        if details['name'].lower().startswith(prefix):
            contacts_with_prefix.append(details['name'])
    return contacts_with_prefix

def get_contact_names(contacts):
    """
    Returns a sorted list of all contact names.
    """
    contact_names = []
    for details in contacts.values():
        contact_names.append(details['name'])
    contact_names.sort()
    return contact_names

def get_phone_by_partial_name(contacts, partial_name):
    """
    Returns the phone numbers of contacts whose names contain the partial name.
    """
    partial_name = partial_name.lower()
    phone_numbers = []
    for details in contacts.values():
        if partial_name in details['name'].lower():
            phone_numbers.append(details['phone'])
    return phone_numbers

def merge_contact_lists(contacts1, contacts2):
    """
    Merges two contact lists into one.
    """
    merged_contacts = contacts1.copy()
    for key, value in contacts2.items():
        if key not in merged_contacts:
            merged_contacts[key] = value
    return merged_contacts
