# Contact Manager Problem Statement

## Introduction

You are required to implement a contact manager that allows users to perform various operations on their contact list. The contact manager should support functionalities like adding a new contact, searching for a contact, deleting a contact, updating a contact's phone number, and retrieving various information about the contacts.

## Functions to Implement

1. `add_contact(contacts, name, phone)`: Adds a new contact with the given name and phone number.
   - If the phone number is not valid (not 10 digits), return "Invalid phone number."
   - If the contact already exists, it should not overwrite the existing contact.

2. `search_contact(contacts, name)`: Searches for a contact by name and returns the phone number or "Not found".

3. `delete_contact(contacts, name)`: Deletes a contact by name and returns `True` if successful, otherwise `False`.

4. `update_contact_phone(contacts, name, new_phone)`: Updates the phone number of an existing contact.
   - If the contact does not exist, return "Contact not found."
   - If the new phone number is not valid, return "Invalid phone number."

5. `get_all_contacts(contacts)`: Returns a list of all contact names.

6. `count_contacts(contacts)`: Returns the total number of contacts.

7. `get_contacts_by_prefix(contacts, prefix)`: Returns a list of contacts whose names start with the given prefix.

8. `get_contact_names(contacts)`: Returns a sorted list of all contact names.

9. `get_phone_by_partial_name(contacts, partial_name)`: Returns the phone numbers of contacts whose names contain the partial name.

10. `merge_contact_lists(contacts1, contacts2)`: Merges two contact lists into one.

## Sample Input and Output

### Example 1: Adding and Searching for a Contact

```python
contacts = {}
contacts = add_contact(contacts, "Alice", "1234567890")
print(search_contact(contacts, "Alice"))  # Output: "1234567890"

### Example 2 : Deleting a Contact

```python
contacts = {}
contacts = add_contact(contacts, "Bob", "1111111111")
print(delete_contact(contacts, "Bob"))  # Output: True
print(search_contact(contacts, "Bob"))  # Output: "Not found"

### Example 3 : Updating a Contact's Phone Number
```python 
contacts = {}
contacts = add_contact(contacts, "Charlie", "2222222222")
contacts = update_contact_phone(contacts, "Charlie", "3333333333")
print(search_contact(contacts, "Charlie"))  # Output: "3333333333"

### Example 4: Counting Contacts
```python
contacts = {}
contacts = add_contact(contacts, "David", "4444444444")
contacts = add_contact(contacts, "Eve", "5555555555")
print(count_contacts(contacts))  # Output: 2

### Example 5 : Getting Contacts by Prefix
```python
contacts = {}
contacts = add_contact(contacts, "Frank", "6666666666")
contacts = add_contact(contacts, "Fiona", "7777777777")
print(get_contacts_by_prefix(contacts, "Fi"))  # Output: ["Fiona"]

### Example 6 : Merging Contact Lists
```python
contacts1 = {}
contacts1 = add_contact(contacts1, "Grace", "8888888888")
contacts2 = {}
contacts2 = add_contact(contacts2, "Heidi", "9999999999")
merged_contacts = merge_contact_lists(contacts1, contacts2)
print(search_contact(merged_contacts, "Grace"))  # Output: "8888888888"
print(search_contact(merged_contacts, "Heidi"))  # Output: "9999999999"
