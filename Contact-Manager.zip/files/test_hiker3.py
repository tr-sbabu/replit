from hiker import add_contact, search_contact, get_contact_names, get_phone_by_partial_name, merge_contact_lists

def test_get_contact_names():
    contacts = {}
    contacts = add_contact(contacts, "Jack", "1010101010")
    contacts = add_contact(contacts, "Jill", "2020202020")
    assert get_contact_names(contacts) == ["Jack", "Jill"]

def test_get_phone_by_partial_name():
    contacts = {}
    contacts = add_contact(contacts, "Karen", "3030303030")
    contacts = add_contact(contacts, "Karl", "4040404040")
    assert set(get_phone_by_partial_name(contacts, "Kar")) == {"3030303030", "4040404040"}

def test_merge_contact_lists():
    contacts1 = {}
    contacts1 = add_contact(contacts1, "Leo", "5050505050")
    contacts2 = {}
    contacts2 = add_contact(contacts2, "Mona", "6060606060")
    merged_contacts = merge_contact_lists(contacts1, contacts2)
    assert search_contact(merged_contacts, "Leo") == "5050505050"
    assert search_contact(merged_contacts, "Mona") == "6060606060"
