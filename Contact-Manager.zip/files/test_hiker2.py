from hiker import add_contact, search_contact, update_contact_phone, get_all_contacts, count_contacts, get_contacts_by_prefix

def test_add_and_update_contact():
    contacts = {}
    contacts = add_contact(contacts, "David", "2222222222")
    contacts = update_contact_phone(contacts, "David", "3333333333")
    assert search_contact(contacts, "David") == "3333333333"

def test_get_all_contacts():
    contacts = {}
    contacts = add_contact(contacts, "Eve", "4444444444")
    contacts = add_contact(contacts, "Frank", "5555555555")
    assert set(get_all_contacts(contacts)) == {"Eve", "Frank"}

def test_count_contacts():
    contacts = {}
    contacts = add_contact(contacts, "Grace", "6666666666")
    contacts = add_contact(contacts, "Heidi", "7777777777")
    assert count_contacts(contacts) == 2

def test_get_contacts_by_prefix():
    contacts = {}
    contacts = add_contact(contacts, "Isaac", "8888888888")
    contacts = add_contact(contacts, "Ivan", "9999999999")
    assert set(get_contacts_by_prefix(contacts, "I")) == {"Isaac", "Ivan"}
