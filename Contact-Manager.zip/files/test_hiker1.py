from hiker import add_contact, search_contact, delete_contact

def test_add_contact():
    contacts = {}
    contacts = add_contact(contacts, "Alice", "1234567890")
    assert search_contact(contacts, "Alice") == "1234567890"

def test_delete_contact():
    contacts = {}
    contacts = add_contact(contacts, "Bob", "1111111111")
    assert delete_contact(contacts, "Bob") == True
    assert search_contact(contacts, "Bob") == "Not found"

def test_search_contact_not_found():
    contacts = {}
    assert search_contact(contacts, "Charlie") == "Not found"
