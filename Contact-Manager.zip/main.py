from hiker import add_contact, search_contact, delete_contact
def test_add_contact():
    contacts = {}
    contacts = add_contact(contacts, "Alice", "1234567890")
    assert search_contact(contacts, "Alice") == "1234567890"
    print("test_add_contact passed")

def test_delete_contact():
    contacts = {}
    contacts = add_contact(contacts, "Bob", "1111111111")
    assert delete_contact(contacts, "Bob") == True
    assert search_contact(contacts, "Bob") == "Not found"
    print("test_delete_contact passed")

def test_search_contact_not_found():
    contacts = {}
    assert search_contact(contacts, "Charlie") == "Not found"
    print("test_search_contact_not_found passed")

    # Running the tests
test_add_contact()
test_delete_contact()
test_search_contact_not_found()

from hiker import add_contact, search_contact, update_contact_phone, get_all_contacts, count_contacts, get_contacts_by_prefix

def test_add_and_update_contact():
    contacts = {}
    contacts = add_contact(contacts, "David", "2222222222")
    contacts = update_contact_phone(contacts, "David", "3333333333")
    assert search_contact(contacts, "David") == "3333333333"
    print("test_add_and_update_contact passed")

def test_get_all_contacts():
    contacts = {}
    contacts = add_contact(contacts, "Eve", "4444444444")
    contacts = add_contact(contacts, "Frank", "5555555555")
    assert set(get_all_contacts(contacts)) == {"Eve", "Frank"}
    print("test_get_all_contacts passed")

def test_count_contacts():
    contacts = {}
    contacts = add_contact(contacts, "Grace", "6666666666")
    contacts = add_contact(contacts, "Heidi", "7777777777")
    assert count_contacts(contacts) == 2
    print("test_count_contacts passed")

def test_get_contacts_by_prefix():
    contacts = {}
    contacts = add_contact(contacts, "Isaac", "8888888888")
    contacts = add_contact(contacts, "Ivan", "9999999999")
    assert set(get_contacts_by_prefix(contacts, "I")) == {"Isaac", "Ivan"}
    print("test_get_contacts_by_prefix passed")

    # Running the tests
test_add_and_update_contact()
test_get_all_contacts()
test_count_contacts()
test_get_contacts_by_prefix()


from hiker import add_contact, search_contact, get_contact_names, get_phone_by_partial_name, merge_contact_lists

def test_get_contact_names():
    contacts = {}
    contacts = add_contact(contacts, "Jack", "1010101010")
    contacts = add_contact(contacts, "Jill", "2020202020")
    assert get_contact_names(contacts) == ["Jack", "Jill"]
    print("test_get_contact_names passed")

def test_get_phone_by_partial_name():
    contacts = {}
    contacts = add_contact(contacts, "Karen", "3030303030")
    contacts = add_contact(contacts, "Karl", "4040404040")
    assert set(get_phone_by_partial_name(contacts, "Kar")) == {"3030303030", "4040404040"}
    print("test_get_phone_by_partial_name passed")

def test_merge_contact_lists():
    contacts1 = {}
    contacts1 = add_contact(contacts1, "Leo", "5050505050")
    contacts2 = {}
    contacts2 = add_contact(contacts2, "Mona", "6060606060")
    merged_contacts = merge_contact_lists(contacts1, contacts2)
    assert search_contact(merged_contacts, "Leo") == "5050505050"
    assert search_contact(merged_contacts, "Mona") == "6060606060"
    print("test_merge_contact_lists passed")

# Running the tests
test_get_contact_names()
test_get_phone_by_partial_name()
test_merge_contact_lists()
